#!/bin/sh

cd ../js

wget http://cdn.robotwebtools.org/roslibjs/r5/roslib.min.js
wget http://cdn.robotwebtools.org/mjpegcanvasjs/current/mjpegcanvas.min.js
wget http://cdn.robotwebtools.org/EventEmitter2/0.4.11/eventemitter2.min.js
#wget http://cdn.robotwebtools.org/nav2djs/current/nav2d.min.js
wget http://cdn.robotwebtools.org/EaselJS/0.6.0/easeljs.min.js
wget http://cdn.robotwebtools.org/ros2djs/r2/ros2d.min.js
wget http://cdn.robotwebtools.org/ros3djs/current/ros3d.min.js
wget http://threejs.org/build/three.min.js
wget http://code.jquery.com/jquery-1.10.2.min.js
wget http://d3lp1msu2r81bx.cloudfront.net/kjs/js/lib/kinetic-v5.1.0.min.js

